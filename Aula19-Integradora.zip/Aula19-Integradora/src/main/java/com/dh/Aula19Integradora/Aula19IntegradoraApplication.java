package com.dh.Aula19Integradora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula19IntegradoraApplication {

	public static void main(String[] args) {
		SpringApplication.run(Aula19IntegradoraApplication.class, args);
	}

}
