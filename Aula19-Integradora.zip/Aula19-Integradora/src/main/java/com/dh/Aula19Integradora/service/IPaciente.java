package com.dh.Aula19Integradora.service;

import com.dh.Aula19Integradora.domain.Paciente;

import java.util.List;

public interface IPaciente {

    //criar metodos descritos no exercicio

    List<Paciente> listaPaciente(); // chamar lista de pacientes

    Paciente pacientePorEmail(String email); // chamar lista pelos emails





}
